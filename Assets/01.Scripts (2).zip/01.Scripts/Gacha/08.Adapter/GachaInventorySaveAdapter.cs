using UnityEngine;

namespace PixelRestaurant.Gacha
{
    /// <summary>
    /// GachaInventory�� ���� ������
    /// PlayerData�� ���� �����ͷ� �����Ѵ�.
    /// </summary>
    public class GachaInventorySaveAdapter : MonoBehaviour
    {
        [SerializeField]
        private GachaInventory gachaInventory;

        private void Awake()
        {
            if (gachaInventory == null)
                gachaInventory = GachaInventory.Instance;
        }

        private void Start()
        {
            if (gachaInventory != null)
            {
                gachaInventory.LoadFromPlayerData();
            }
        }

        private void OnEnable()
        {
            if (gachaInventory != null)
            {
                gachaInventory.OnInventoryChanged
                    += SyncInventoryToPlayerData;
            }
        }

        private void OnDisable()
        {
            if (gachaInventory != null)
            {
                gachaInventory.OnInventoryChanged
                    -= SyncInventoryToPlayerData;
            }
        }

        private void SyncInventoryToPlayerData()
        {
            if (GameManager.instance == null)
            {
                Debug.LogError(
                    "[��í ���� Adapter] GameManager�� �����ϴ�."
                );
                return;
            }

            PlayerData playerData =
                GameManager.instance.PlayerData;

            if (playerData == null)
            {
                Debug.LogError(
                    "[��í ���� Adapter] PlayerData�� �����ϴ�."
                );
                return;
            }

            if (playerData.gachaInventory == null)
            {
                playerData.gachaInventory =
                    new GachaInventoryData();
            }

            playerData.gachaInventory.items.Clear();

            foreach (var pair in
                     gachaInventory.GetAllItems())
            {
                playerData.gachaInventory.items.Add(
                    new GachaOwnedItemData
                    {
                        itemId = pair.Key,
                        count = pair.Value,
                        isNew =
                            gachaInventory.IsNewItem(pair.Key)
                    }
                );
            }

            Debug.Log(
                "[��í ���� Adapter] " +
                "PlayerData�� �κ��丮 ����ȭ �Ϸ�"
            );

            // �׽�Ʈ �ܰ迡���� ��� ����
            //if (SaveManager.Instance != null)
            //{
            //    SaveManager.Instance.Save();
            //}
        }
    }
}