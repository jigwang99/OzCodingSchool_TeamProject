using System.Collections.Generic;
using UnityEngine;

namespace PixelRestaurant.Gacha
{
    /// <summary>
    /// GachaManager�� ��� �̺�Ʈ��
    /// GachaInventory�� �����ϴ� Adapter
    /// </summary>
    public class GachaInventoryAdapter : MonoBehaviour
    {
        [SerializeField]
        private GachaManager gachaManager;

        [SerializeField]
        private GachaInventory gachaInventory;

        private void Awake()
        {
            if (gachaManager == null)
                gachaManager = GachaManager.Instance;

            if (gachaInventory == null)
                gachaInventory = GachaInventory.Instance;
        }

        private void OnEnable()
        {
            if (gachaManager != null)
                gachaManager.OnGachaItemsDrawn += HandleGachaItemsDrawn;
        }

        private void OnDisable()
        {
            if (gachaManager != null)
                gachaManager.OnGachaItemsDrawn -= HandleGachaItemsDrawn;
        }

        private void HandleGachaItemsDrawn(
            List<GachaItem> results)
        {
            if (gachaInventory == null)
            {
                Debug.LogError(
                    "[��í �κ��丮 Adapter] GachaInventory�� �����ϴ�."
                );

                return;
            }

            if (results == null || results.Count == 0)
                return;

            foreach (GachaItem item in results)
            {
                if (item == null)
                    continue;

                gachaInventory.AddItem(item.ItemId);
            }

            Debug.Log(
                $"[��í �κ��丮 Adapter] " +
                $"{results.Count}�� ������ �κ��丮 �ݿ�"
            );
        }
    }
}