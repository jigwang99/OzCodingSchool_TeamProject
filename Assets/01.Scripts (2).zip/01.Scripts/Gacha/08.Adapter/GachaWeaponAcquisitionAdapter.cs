using PixelRestaurant.Data;
using System.Collections.Generic;
using UnityEngine;

namespace PixelRestaurant.Gacha
{
    /// <summary>
    /// ��í���� ���⸦ �̾��� ��
    /// ���� PlayerWeaponEquipment�� ȹ�� �ý������� �����Ѵ�.
    /// </summary>
    public class GachaWeaponAcquisitionAdapter : MonoBehaviour
    {
        [SerializeField]
        private GachaManager gachaManager;

        [SerializeField]
        private PlayerWeaponEquipment weaponEquipment;

        private void Awake()
        {
            if (gachaManager == null)
                gachaManager = GachaManager.Instance;

            if (weaponEquipment == null)
                weaponEquipment =
                    FindObjectOfType<PlayerWeaponEquipment>();
        }

        private void OnEnable()
        {
            if (gachaManager != null)
            {
                gachaManager.OnGachaItemsDrawn
                    += HandleGachaItemsDrawn;
            }
        }

        private void OnDisable()
        {
            if (gachaManager != null)
            {
                gachaManager.OnGachaItemsDrawn
                    -= HandleGachaItemsDrawn;
            }
        }

        private void HandleGachaItemsDrawn(
            List<GachaItem> results)
        {
            if (weaponEquipment == null)
            {
                Debug.LogError(
                    "[��í ���� Adapter] " +
                    "PlayerWeaponEquipment�� �����ϴ�."
                );

                return;
            }

            if (results == null)
                return;

            foreach (GachaItem item in results)
            {
                if (item == null)
                    continue;

                // ���⸸ ���� ���� �κ��丮�� �߰�
                if (item.Group != GachaGroup.Weapon)
                    continue;

                bool success =
                    weaponEquipment.AcquireWeapon(
                        item.ItemId
                    );

                if (success)
                {
                    Debug.Log(
                        $"[��í ���� Adapter] " +
                        $"{item.ItemName} ȹ�� �Ϸ�"
                    );
                }
                else
                {
                    Debug.LogWarning(
                        $"[��í ���� Adapter] " +
                        $"{item.ItemId} ȹ�� ����"
                    );
                }
            }
        }
    }
}