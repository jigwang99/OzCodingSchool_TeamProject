using System.Collections.Generic;
using UnityEngine;
using PixelRestaurant.Data;

namespace PixelRestaurant.Gacha
{
    /// <summary>
    /// ���� �˾� ��ü ����
    /// ���� GachaManager�� ����ϴ� ��í Ǯ�� ������ ������ ǥ���Ѵ�.
    /// </summary>
    public class RistPopupController : MonoBehaviour
    {
        [Header("Popup")]
        [SerializeField] private GameObject ristPopup;

        [Header("List Content")]
        [SerializeField] private Transform content;

        [Header("Rist Item Card")]
        [SerializeField] private RistItemCard itemCardPrefab;

        private GachaGroup _currentGroup = GachaGroup.Weapon;

        private void Awake()
        {
            if (ristPopup != null)
            {
                ristPopup.SetActive(false);
            }
        }

        private void Update()
        {
            // J Ű�� ���� ���� / �ݱ�
            if (Input.GetKeyDown(KeyCode.J))
            {
                ToggleRist();
            }
        }

        /// <summary>
        /// ���� ���� / �ݱ�
        /// </summary>
        public void ToggleRist()
        {
            if (ristPopup == null)
                return;

            if (ristPopup.activeSelf)
            {
                CloseRist();
            }
            else
            {
                OpenRist();
            }
        }

        /// <summary>
        /// ���� ����
        /// </summary>
        public void OpenRist()
        {
            if (ristPopup == null)
                return;

            ristPopup.SetActive(true);

            // ó�� ������ �� Weapon ǥ��
            ShowWeapons();
        }

        /// <summary>
        /// ���� �ݱ�
        /// </summary>
        public void CloseRist()
        {
            if (ristPopup == null)
                return;

            ristPopup.SetActive(false);
        }

        /// <summary>
        /// Weapon ��
        /// </summary>
        public void ShowWeapons()
        {
            ShowGroup(GachaGroup.Weapon);
        }

        /// <summary>
        /// Furniture ��
        /// </summary>
        public void ShowFurniture()
        {
            ShowGroup(GachaGroup.Furniture);
        }

        /// <summary>
        /// Recipe ��
        /// </summary>
        public void ShowRecipes()
        {
            ShowGroup(GachaGroup.Recipe);
        }

        /// <summary>
        /// ������ ��í �׷��� �������� ������ ǥ��
        /// </summary>
        private void ShowGroup(GachaGroup group)
        {
            _currentGroup = group;

            ClearContent();

            if (GachaManager.Instance == null)
            {
                Debug.LogError(
                    "[Rist] GachaManager�� ã�� �� �����ϴ�."
                );

                return;
            }

            GachaPoolData poolData =
                GachaManager.Instance.GetPoolData(group);

            if (poolData == null)
            {
                Debug.LogWarning(
                    $"[Rist] {group} ��í Ǯ�� �����ϴ�."
                );

                return;
            }

            // ��� ���Ƽ�� �������� �����´�.
            AddItemsByRarity(poolData, GachaRarity.Common);
            AddItemsByRarity(poolData, GachaRarity.Rare);
            AddItemsByRarity(poolData, GachaRarity.Unique);
            AddItemsByRarity(poolData, GachaRarity.Epic);
        }

        /// <summary>
        /// Ư�� ���Ƽ�� �������� ī��� ����
        /// </summary>
        private void AddItemsByRarity(
            GachaPoolData poolData,
            GachaRarity rarity)
        {
            List<GachaItem> items =
                poolData.GetItemsByRarity(rarity);

            if (items == null)
                return;

            foreach (GachaItem item in items)
            {
                if (item == null)
                    continue;

                CreateItemCard(item);
            }
        }

        /// <summary>
        /// ���� ������ ī�� ����
        /// </summary>
        private void CreateItemCard(GachaItem item)
        {
            if (content == null)
            {
                Debug.LogError(
                    "[Rist] Content�� ������� �ʾҽ��ϴ�."
                );

                return;
            }

            if (itemCardPrefab == null)
            {
                Debug.LogError(
                    "[Rist] RistItemCard Prefab�� ������� �ʾҽ��ϴ�."
                );

                return;
            }

            RistItemCard card =
                Instantiate(itemCardPrefab, content);

            card.Setup(item);
        }

        /// <summary>
        /// ���� ī�� ����
        /// </summary>
        private void ClearContent()
        {
            if (content == null)
                return;

            for (int i = content.childCount - 1; i >= 0; i--)
            {
                Destroy(content.GetChild(i).gameObject);
            }
        }
    }
}