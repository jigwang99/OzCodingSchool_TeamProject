using UnityEngine;

namespace PixelRestaurant.Gacha
{
    /// <summary>
    /// ������ Weapon / Furniture / Recipe �� ����
    /// </summary>
    public class RistTabController : MonoBehaviour
    {
        [SerializeField]
        private RistPopupController ristPopupController;

        /// <summary>
        /// Weapon ��
        /// </summary>
        public void OnWeaponTab()
        {
            if (ristPopupController == null)
                return;

            ristPopupController.ShowWeapons();
        }

        /// <summary>
        /// Furniture ��
        /// </summary>
        public void OnFurnitureTab()
        {
            if (ristPopupController == null)
                return;

            ristPopupController.ShowFurniture();
        }

        /// <summary>
        /// Recipe ��
        /// </summary>
        public void OnRecipeTab()
        {
            if (ristPopupController == null)
                return;

            ristPopupController.ShowRecipes();
        }
    }
}