using UnityEngine;
using UnityEngine.UI;
using TMPro;
using PixelRestaurant.Data;

namespace PixelRestaurant.Gacha
{
    /// <summary>
    /// �̱� ��� ī�忡 ������ ���� ǥ��
    /// NEW ����, �����۸�, ���Ƽ ����, ���, ���� ǥ��
    /// </summary>
    public class GachaResultItemDisplay : MonoBehaviour
    {
        [SerializeField]
        private TextMeshProUGUI itemNameText;

        [SerializeField]
        private TextMeshProUGUI rarityText;

        [SerializeField]
        private TextMeshProUGUI gradeText;

        [SerializeField]
        private Image newBadge;

        [SerializeField]
        private TextMeshProUGUI countText;

        // ========== ���Ƽ ���� ==========
        private Color _commonColor = Color.white;                    // �Ͼ�
        private Color _rareColor = Color.green;                      // �ʷ�
        private Color _uniqueColor = Color.yellow;                   // ���
        private Color _epicColor = new Color(0.5f, 0, 1);           // ����

        private void Start()
        {
            // ��Ʈ ũ�� ����
            if (itemNameText != null)
                itemNameText.fontSize = 7;

            if (rarityText != null)
                rarityText.fontSize = 7;

            if (gradeText != null)
                gradeText.fontSize = 7;

            if (countText != null)
                countText.fontSize = 6;
        }

        /// <summary>
        /// ������ ������ ī�忡 ǥ��
        /// </summary>
        /// <param name="item">ǥ���� ������</param>
        /// <param name="isNew">NEW ���� ����</param>
        public void SetItemInfo(GachaItem item, bool isNew)
        {
            if (item == null)
            {
                Debug.LogError("[ī��] �������� null�Դϴ�.");
                return;
            }

            // ������ �̸� ǥ��
            if (itemNameText != null)
                itemNameText.text = item.ItemName;

            // ���Ƽ ǥ�� (���� ����)
            if (rarityText != null)
            {
                rarityText.text = item.Rarity.ToString();
                rarityText.color = GetRarityColor(item.Rarity);
            }

            // ��� ǥ��
            if (gradeText != null)
                gradeText.text = $"Lv.{item.Grade}";

            // NEW ����
            if (newBadge != null)
            {
                newBadge.gameObject.SetActive(isNew);
            }

            // ������ SetCount()���� ���� ó��
            if (!isNew && countText != null)
            {
                countText.gameObject.SetActive(false);
            }

            Debug.Log($"[ī��] {item.GetDisplayName()} ���� ǥ�� (NEW: {isNew})");
        }

        /// <summary>
        /// ������ ���� ǥ��
        /// </summary>
        /// <param name="count">����</param>
        public void SetCount(int count)
        {
            if (countText == null)
                return;

            if (count > 1)
            {
                countText.text = $"x{count}";
                countText.gameObject.SetActive(true);
            }
            else
            {
                countText.gameObject.SetActive(false);
            }
        }

        /// <summary>
        /// ���Ƽ�� ���� ��ȯ
        /// </summary>
        /// <param name="rarity">���Ƽ</param>
        /// <returns>����</returns>
        private Color GetRarityColor(GachaRarity rarity)
        {
            return rarity switch
            {
                GachaRarity.Common => _commonColor,
                GachaRarity.Rare => _rareColor,
                GachaRarity.Unique => _uniqueColor,
                GachaRarity.Epic => _epicColor,
                _ => _commonColor
            };
        }

        /// <summary>
        /// ī�� ���� (Ǯ�� ��ȯ ��)
        /// </summary>
        public void ResetCard()
        {
            if (itemNameText != null)
                itemNameText.text = "";

            if (rarityText != null)
                rarityText.text = "";

            if (gradeText != null)
                gradeText.text = "";

            if (newBadge != null)
                newBadge.gameObject.SetActive(false);

            if (countText != null)
                countText.gameObject.SetActive(false);
        }
    }
}
