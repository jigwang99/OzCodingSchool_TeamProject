
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using PixelRestaurant.Data;

namespace PixelRestaurant.Gacha
{
    /// <summary>
    /// ��í �κ��丮 UI ����
    ///
    /// - �κ��丮 ���� / �ݱ�
    /// - ��í �˾��� ��ȣ ��Ÿ������ ����
    /// - Weapon / Furniture / Recipe ��
    /// - ������ ī�� ����
    /// - ������ ���� ǥ��
    /// - NEW ǥ��
    /// </summary>
    public class GachaInventoryUI : MonoBehaviour
    {
        // =========================================================
        // �κ��丮 �˾�
        // =========================================================

        [Header("�κ��丮 �˾�")]
        [SerializeField] private GameObject inventoryPopup;

        // =========================================================
        // ��í UI
        // =========================================================

        [Header("��í UI")]
        [SerializeField] private GachaUIController gachaUI;

        [Header("�׽�Ʈ")]
        [SerializeField] private Button clearGachaInventoryButton;

        // =========================================================
        // �κ��丮 ��
        // =========================================================

        [Header("�κ��丮 ��")]
        [SerializeField] private Button weaponTab;
        [SerializeField] private Button furnitureTab;
        [SerializeField] private Button recipeTab;

        private GachaGroup _currentTab =
            GachaGroup.Weapon;

        // =========================================================
        // �κ��丮 ī��
        // =========================================================

        [Header("�κ��丮 ī��")]
        [SerializeField] private Transform inventoryGrid;

        [SerializeField] private GameObject itemCardPrefab;

        // =========================================================
        // Unity
        // =========================================================

        private void Start()
        {
            RegisterTabEvents();
            RegisterTestEvents();

            Debug.Log(
                "[�κ��丮 UI] �ʱ�ȭ �Ϸ�"
            );
        }
        private void RegisterTestEvents()
        {
            if (clearGachaInventoryButton == null)
                return;

            clearGachaInventoryButton.onClick.RemoveAllListeners();

            clearGachaInventoryButton.onClick.AddListener(
                ClearGachaInventory
            );
        }
        // =========================================================
        // �� �̺�Ʈ
        // =========================================================

        private void RegisterTabEvents()
        {
            if (weaponTab != null)
            {
                weaponTab.onClick.AddListener(
                    () => SelectTab(GachaGroup.Weapon)
                );
            }

            if (furnitureTab != null)
            {
                furnitureTab.onClick.AddListener(
                    () => SelectTab(GachaGroup.Furniture)
                );
            }

            if (recipeTab != null)
            {
                recipeTab.onClick.AddListener(
                    () => SelectTab(GachaGroup.Recipe)
                );
            }
        }

        // =========================================================
        // �κ��丮 ����
        // =========================================================

        public void OpenInventory()
        {
            // -----------------------------------------------------
            // ��í �˾��� ���� �ִٸ� �ݱ�
            // -----------------------------------------------------

            if (gachaUI != null)
            {
                gachaUI.OpenGachaPopup();
            }

            // -----------------------------------------------------
            // �κ��丮 ����
            // -----------------------------------------------------

            if (inventoryPopup == null)
            {
                Debug.LogError(
                    "[�κ��丮 UI] inventoryPopup�� �������� �ʾҽ��ϴ�."
                );

                return;
            }

            inventoryPopup.SetActive(true);

            RefreshInventoryDisplay();

            Debug.Log(
                "[�κ��丮 UI] �κ��丮 �˾� ����"
            );
        }

        // =========================================================
        // �κ��丮 �ݱ�
        // =========================================================

        public void CloseInventory()
        {
            if (inventoryPopup == null)
                return;

            inventoryPopup.SetActive(false);

            Debug.Log(
                "[�κ��丮 UI] �κ��丮 �˾� ����"
            );
        }

        // =========================================================
        // �κ��丮 ����
        // =========================================================

        public bool IsInventoryOpen()
        {
            return inventoryPopup != null &&
                   inventoryPopup.activeSelf;
        }

        // =========================================================
        // �� ����
        // =========================================================

        private void SelectTab(
            GachaGroup group)
        {
            _currentTab = group;

            RefreshInventoryDisplay();

            Debug.Log(
                $"[�κ��丮 UI] �� ����: {group}"
            );
        }

        // =========================================================
        // �κ��丮 ����
        // =========================================================

        public void RefreshInventoryDisplay()
        {
            GachaInventory inventory =
                GachaInventory.Instance;

            if (inventory == null)
            {
                Debug.LogError(
                    "[�κ��丮 UI] GachaInventory�� ã�� �� �����ϴ�."
                );

                return;
            }

            if (GachaManager.Instance == null)
            {
                Debug.LogError(
                    "[�κ��丮 UI] GachaManager�� ã�� �� �����ϴ�."
                );

                return;
            }

            GachaPoolData poolData =
                GachaManager.Instance.GetPoolData(
                    _currentTab
                );

            if (poolData == null)
            {
                Debug.LogError(
                    $"[�κ��丮 UI] {_currentTab} Pool�� ã�� �� �����ϴ�."
                );

                return;
            }

            // -----------------------------------------------------
            // ���� ī�� ����
            // -----------------------------------------------------

            ClearInventoryCards();

            // -----------------------------------------------------
            // ���� ���� ������ ��ȸ
            // -----------------------------------------------------

            List<string> itemIds =
                inventory.GetItemsInGroup(
                    _currentTab,
                    poolData
                ); 
                itemIds.Sort((idA, idB) =>
                {
                    GachaItem itemA =
                        poolData.Items.Find(i => i.ItemId == idA);

                    GachaItem itemB =
                        poolData.Items.Find(i => i.ItemId == idB);

                    if (itemA == null)
                        return 1;

                    if (itemB == null)
                        return -1;

                    // 1����: ���
                    int rarityCompare =
                        GetRarityOrder(itemA.Rarity)
                        .CompareTo(
                            GetRarityOrder(itemB.Rarity)
                        );

                    if (rarityCompare != 0)
                        return rarityCompare;

                    // 2����: ���
                    int gradeCompare =
                        itemA.Grade.CompareTo(itemB.Grade);

                    if (gradeCompare != 0)
                        return gradeCompare;

                    // 3����: ���� ��� �̸���
                    return string.Compare(
                        itemA.ItemName,
                        itemB.ItemName,
                        System.StringComparison.Ordinal
                    );
                });

            if (itemIds.Count == 0)
            {
                Debug.Log(
                    $"[�κ��丮 UI] {_currentTab} �������� �����ϴ�."
                );

                return;
            }

            // -----------------------------------------------------
            // ī�� ����
            // -----------------------------------------------------

            foreach (string itemId in itemIds)
            {
                CreateItemCard(
                    itemId,
                    inventory,
                    poolData
                );
            }

            Debug.Log(
                $"[�κ��丮 UI] {itemIds.Count}�� ������ ǥ��"
            );
        }

        // =========================================================
        // ���� ī�� ����
        // =========================================================

        private void ClearInventoryCards()
        {
            if (inventoryGrid == null)
                return;

            for (int i = inventoryGrid.childCount - 1;
                 i >= 0;
                 i--)
            {
                Transform child =
                    inventoryGrid.GetChild(i);

                Destroy(child.gameObject);
            }
        }

        // =========================================================
        // ������ ī�� ����
        // =========================================================

        private void CreateItemCard(
            string itemId,
            GachaInventory inventory,
            GachaPoolData poolData)
        {
            if (itemCardPrefab == null)
            {
                Debug.LogError(
                    "[�κ��丮 UI] itemCardPrefab�� �������� �ʾҽ��ϴ�."
                );

                return;
            }

            if (inventoryGrid == null)
            {
                Debug.LogError(
                    "[�κ��丮 UI] inventoryGrid�� �������� �ʾҽ��ϴ�."
                );

                return;
            }

            // -----------------------------------------------------
            // Pool �����Ϳ��� ������ ã��
            // -----------------------------------------------------

            GachaItem item =
                poolData.Items.Find(
                    i => i.ItemId == itemId
                );

            if (item == null)
            {
                Debug.LogError(
                    $"[�κ��丮 UI] {itemId} �������� ã�� �� �����ϴ�."
                );

                return;
            }

            // -----------------------------------------------------
            // ī�� ����
            // -----------------------------------------------------

            GameObject card =
                Instantiate(
                    itemCardPrefab,
                    inventoryGrid
                );

            if (card == null)
                return;

            card.name =
                $"{item.ItemName}_InventoryCard";


            // -----------------------------------------------------
            // ���� ����
            // -----------------------------------------------------

            int count =
                inventory.GetItemCount(itemId);

            // -----------------------------------------------------
            // NEW ����
            // -----------------------------------------------------

            bool isNew =
                inventory.IsNewItem(itemId);

            // -----------------------------------------------------
            // ī�� ǥ�� ������Ʈ
            //
            // ���� ������Ʈ�� Inventory prefab��
            // GachaResultItemDisplay�� ����ϴ� ������
            // ������ �� �ֵ��� ���� ã��,
            // ������ ���� ���
            // -----------------------------------------------------

            GachaResultItemDisplay display =
                card.GetComponent<GachaResultItemDisplay>();

            if (display != null)
            {
                display.SetItemInfo(
                    item,
                    isNew
                );

                display.SetCount(
                    count
                );
            }
            else
            {
                Debug.LogError(
                    $"[�κ��丮 UI] {card.name}�� " +
                    "GachaResultItemDisplay�� �����ϴ�."
                );
            }

            // -----------------------------------------------------
            // NEW ��ư
            // -----------------------------------------------------

            SetupNewBadge(
                card,
                item,
                inventory,
                isNew
            );
        }

        // =========================================================
        // NEW ���� ����
        // =========================================================

        private void SetupNewBadge(
            GameObject card,
            GachaItem item,
            GachaInventory inventory,
            bool isNew)
        {
            if (!isNew)
                return;

            Transform newBadgeTransform =
                card.transform.Find("NewBadge");

            if (newBadgeTransform == null)
                return;

            newBadgeTransform.gameObject
                .SetActive(true);

            Button newBadgeButton =
                newBadgeTransform.GetComponent<Button>();

            if (newBadgeButton == null)
                return;

            // �ߺ� ��� ����
            newBadgeButton.onClick.RemoveAllListeners();

            newBadgeButton.onClick.AddListener(
                () =>
                {
                    inventory.MarkAsViewed(
                        item.ItemId
                    );

                    newBadgeTransform.gameObject
                        .SetActive(false);

                    Debug.Log(
                        $"[�κ��丮 UI] " +
                        $"{item.ItemName} NEW ǥ�� ����"
                    );
                }
            );
        }

        // =========================================================
        // Ư�� �׷��� ������ ���� ����
        // =========================================================

        public int GetItemCountInGroup(
            GachaGroup group)
        {
            GachaInventory inventory =
                GachaInventory.Instance;

            if (inventory == null)
                return 0;

            if (GachaManager.Instance == null)
                return 0;

            GachaPoolData poolData =
                GachaManager.Instance.GetPoolData(
                    group
                );

            if (poolData == null)
                return 0;

            return inventory
                .GetItemsInGroup(
                    group,
                    poolData
                )
                .Count;
        }

        // =========================================================
        // �ܺο��� ���� �� ����
        // =========================================================

        public void Refresh()
        {
            RefreshInventoryDisplay();
        }
        private int GetRarityOrder(GachaRarity rarity)
        {
            switch (rarity)
            {
                case GachaRarity.Common:
                    return 0;

                case GachaRarity.Rare:
                    return 1;

                case GachaRarity.Unique:
                    return 2;

                case GachaRarity.Epic:
                    return 3;

                default:
                    return 99;
            }
        }
        // =========================================================
        // �κ��丮 �ʱ�ȭ ��ư �̺�Ʈ ��� (�׽�Ʈ��)
        // =========================================================
        private void ClearGachaInventory()
        {
            GachaInventory inventory =
                GachaInventory.Instance;

            if (inventory == null)
            {
                Debug.LogError(
                    "[�κ��丮 UI] GachaInventory�� ã�� �� �����ϴ�."
                );

                return;
            }

            // �κ��丮 ������ �ʱ�ȭ
            inventory.Clear();

            // ���� ȭ�鵵 ��� ����
            RefreshInventoryDisplay();

            // �׽�Ʈ�� ���� �����ͱ��� ��� �ݿ�
            if (SaveManager.instance != null)
            {
                SaveManager.instance.Save();
            }

            Debug.Log(
                "[�κ��丮 UI] ��í �κ��丮 �ʱ�ȭ �Ϸ�"
            );
        }
    }

}