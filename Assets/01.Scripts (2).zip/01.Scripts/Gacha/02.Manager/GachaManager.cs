using System.Collections.Generic;
using UnityEngine;
using PixelRestaurant.Data;
using System;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

namespace PixelRestaurant.Gacha
{
    /// <summary>
    /// ��í �ý����� �ٽ� ����
    /// ��ȭ �Һ�, ��í ����, ��� ��ȯ
    /// </summary>
    public class GachaManager : MonoBehaviour
    {
        private static GachaManager _instance;

        private Dictionary<GachaGroup, GachaPoolData> _pools
            = new Dictionary<GachaGroup, GachaPoolData>();

        private GachaPitySystem _pitySystem;

        private GachaInventory _inventory;

        // ���� CurrencyManager�� ICurrencyProvider�� ���
        private ICurrencyProvider _currencyProvider;

        private GachaItem _lastDrawnItem;

        public event Action<List<GachaItem>> OnGachaItemsDrawn;
        public static GachaManager Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = FindObjectOfType<GachaManager>();

                    if (_instance == null)
                    {
                        Debug.LogError(
                            "[��í �Ŵ���] GachaManager�� ã�� �� �����ϴ�!"
                        );
                    }
                }

                return _instance;
            }
        }

        private void Awake()
        {
            if (_instance != null && _instance != this)
            {
                Destroy(gameObject);
                return;
            }

            _instance = this;
            DontDestroyOnLoad(gameObject);

            Debug.Log($"[��í] CurrencyManager Ȯ��: {CurrencyManager.instance}");

            if (CurrencyManager.instance != null)
            {
                _currencyProvider = CurrencyManager.instance;
                Debug.Log("[��í] CurrencyProvider ���� �Ϸ�");
            }
            else
            {
                Debug.LogError("[��í] CurrencyManager.instance�� ���� �����ϴ�!");
            }
        }
        /// <summary>
        /// ��í �Ŵ��� �ʱ�ȭ
        /// </summary>
        public void Initialize(
            Dictionary<GachaGroup, GachaPoolData> pools,
            GachaPitySystem pitySystem,
            GachaInventory inventory,
            ICurrencyProvider currencyProvider)
        {
            _pools = pools;
            _pitySystem = pitySystem;
            _inventory = inventory;
            _currencyProvider = currencyProvider;

            Debug.Log("[��í �Ŵ���] �ʱ�ȭ �Ϸ�");
        }

        /// <summary>
        /// ��í ����
        /// 1ȸ / 10ȸ ����
        /// </summary>
        public List<GachaItem> DrawGacha(
        GachaGroup group,
        int pullCount,
        BigNumber costPerPull)
        {
            var results = new List<GachaItem>();

            // =========================
            // �⺻ ����
            // =========================

            if (pullCount != 1 && pullCount != 10)
            {
                Debug.LogWarning(
                    "[��í] �������� �ʴ� �̱� Ƚ���Դϴ�. ����: 1, 10"
                );

                return results;
            }

            if (_pools == null || !_pools.ContainsKey(group))
            {
                Debug.LogError(
                    $"[��í] {group} �׷��� Ǯ�� ã�� �� �����ϴ�."
                );

                return results;
            }

            if (_currencyProvider == null)
            {
                _currencyProvider = CurrencyManager.instance;

                if (_currencyProvider == null)
                {
                    Debug.LogError(
                        "[��í] CurrencyManager�� ã�� �� �����ϴ�!"
                    );

                    return results;
                }

                Debug.Log("[��í] CurrencyProvider �ڵ� ���� �Ϸ�");
            }

            if (_pitySystem == null)
            {
                Debug.LogError(
                    "[��í] PitySystem�� �������� �ʾҽ��ϴ�!"
                );

                return results;
            }

            GachaPoolData poolData = _pools[group];

            Debug.Log(
                $"[��í] {pullCount}ȸ �̱� ���� " +
                $"({group}, ���: {costPerPull} x {pullCount})"
            );

            // =========================
            // ��ü ��� ���� Ȯ��
            // =========================

            BigNumber totalCost = new BigNumber(
                30 * pullCount
            );

            BigNumber currentGold =
                CurrencyManager.instance.GetCurrentGold();

            if (currentGold < totalCost)
            {
                Debug.LogWarning(
                    $"[��í] ��� ����! " +
                    $"�ʿ�: {totalCost}, ����: {currentGold}"
                );

                return results;
            }

            // =========================
            // Pull
            // =========================

            for (int i = 0; i < pullCount; i++)
            {
                // Step 1
                // BigNumber �������� ��� �Һ�
                if (!_currencyProvider.SpendGold(costPerPull))
                {
                    Debug.LogWarning(
                        $"[��í] ��� �Һ� ����! " +
                        $"{i + 1}ȸ������ �̱⸦ �ߴ��մϴ�."
                    );

                    // �߰� �����̹Ƿ� ��� ��ü ���
                    results.Clear();

                    return results;
                }

                // Step 2
                int currentLevel =
                    _pitySystem.GetCurrentPityLevel(group);

                // Step 3
                GachaRarity rarity =
                    DrawRarity(
                        group,
                        currentLevel,
                        poolData
                    );

                // Step 4
                GachaItem item =
                    DrawItem(
                        group,
                        rarity,
                        poolData
                    );

                if (item == null)
                {
                    Debug.LogError(
                        "[��í] �������� ã�� �� �����ϴ�."
                    );

                    // �̱� ����
                    results.Clear();

                    return results;
                }

                // Step 5
                _pitySystem.IncreasePullCount(group);

                // Step 6
                if (_pitySystem.CheckAndLevelUp(
                    group,
                    poolData.PityConfig))
                {
                    Debug.Log(
                        $"[��í] {group} õ�� ������ �� Ȯ�� ����"
                    );
                }

                results.Add(item);
                _lastDrawnItem = item;

                Debug.Log(
                    $"[��í] {i + 1}ȸ: " +
                    $"{item.GetDisplayName()} ȹ�� ({rarity})"
                );
            }

            // =========================
            // ���� ��� ����
            // =========================

            if (results.Count != pullCount)
            {
                Debug.LogWarning(
                    $"[��í] �̱� ����! " +
                    $"��û: {pullCount}ȸ / ���: {results.Count}��"
                );

                results.Clear();
                return results;
            }

            Debug.Log(
                $"[��í] �̱� �Ϸ�: {results.Count}�� ȹ��"
            );

            if (results.Count > 0)
            {
                OnGachaItemsDrawn?.Invoke(results);
            }

            return results;
        }

        // =========================
        // Rarity
        // =========================

        private GachaRarity DrawRarity(
            GachaGroup group,
            int pityLevel,
            GachaPoolData poolData)
        {
            GachaPityConfig config = poolData.PityConfig;

            int commonWeight =
                config.GetWeight(
                    pityLevel,
                    GachaRarity.Common
                );

            int rareWeight =
                config.GetWeight(
                    pityLevel,
                    GachaRarity.Rare
                );

            int uniqueWeight =
                config.GetWeight(
                    pityLevel,
                    GachaRarity.Unique
                );

            int epicWeight =
                config.GetWeight(
                    pityLevel,
                    GachaRarity.Epic
                );

            int totalWeight =
                commonWeight
                + rareWeight
                + uniqueWeight
                + epicWeight;

            if (totalWeight <= 0)
            {
                Debug.LogError(
                    $"[��í] {group} Level {pityLevel}�� " +
                    "����ġ�� 0�Դϴ�!"
                );

                return GachaRarity.Common;
            }

            int randomValue =
                Random.Range(0, totalWeight);

            int cumulativeWeight = 0;

            cumulativeWeight += commonWeight;

            if (randomValue < cumulativeWeight)
                return GachaRarity.Common;

            cumulativeWeight += rareWeight;

            if (randomValue < cumulativeWeight)
                return GachaRarity.Rare;

            cumulativeWeight += uniqueWeight;

            if (randomValue < cumulativeWeight)
                return GachaRarity.Unique;

            return GachaRarity.Epic;
        }

        // =========================
        // Item
        // =========================

        private GachaItem DrawItem(
            GachaGroup group,
            GachaRarity rarity,
            GachaPoolData poolData)
        {
            var candidates =
                poolData.GetItemsByRarity(rarity);

            if (candidates.Count == 0)
            {
                Debug.LogWarning(
                    $"[��í] {group} {rarity} �������� �����ϴ�!"
                );

                return null;
            }

            int totalWeight = 0;

            foreach (var item in candidates)
            {
                totalWeight += item.Weight;
            }

            if (totalWeight <= 0)
            {
                Debug.LogError(
                    $"[��í] {rarity} �������� " +
                    "�� ����ġ�� 0�Դϴ�!"
                );

                return candidates[0];
            }

            int randomValue =
                Random.Range(0, totalWeight);

            int cumulativeWeight = 0;

            foreach (var item in candidates)
            {
                cumulativeWeight += item.Weight;

                if (randomValue < cumulativeWeight)
                    return item;
            }

            return candidates[0];
        }

        // =========================
        // Pool
        // =========================

        public GachaPoolData GetPoolData(
            GachaGroup group)
        {
            if (!_pools.ContainsKey(group))
            {
                Debug.LogError(
                    $"[��í] {group} �׷��� Ǯ�� ã�� �� �����ϴ�."
                );

                return null;
            }

            return _pools[group];
        }

        public Dictionary<GachaGroup, GachaPoolData>
            GetAllPools()
        {
            return new Dictionary<GachaGroup, GachaPoolData>(
                _pools
            );
        }
    }
}