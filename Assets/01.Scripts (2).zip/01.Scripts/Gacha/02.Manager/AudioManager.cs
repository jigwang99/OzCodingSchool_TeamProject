using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance { get; private set; }

    [Header("BGM")]
    [SerializeField] private AudioSource bgmSource;
    [SerializeField] private AudioClip bgm;

    [Header("SFX")]
    [SerializeField] private AudioSource sfxSource;
    [SerializeField] private AudioClip BottonSFX;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);

        // BGM AudioSource �ڵ� ����
        if (bgmSource == null)
        {
            bgmSource = gameObject.AddComponent<AudioSource>();
        }

        // SFX AudioSource �ڵ� ����
        if (sfxSource == null)
        {
            sfxSource = gameObject.AddComponent<AudioSource>();
        }

        // BGM ����
        bgmSource.playOnAwake = false;
        bgmSource.loop = true;

        // SFX ����
        sfxSource.playOnAwake = false;
    }

    private void Start()
    {
        PlayBusinessSceneBGM();
    }

    /// <summary>
    /// BusinessScene ������� ���
    /// </summary>
    public void PlayBusinessSceneBGM()
    {
        if (bgm == null)
        {
            Debug.LogWarning("BGM_BusinessScene�� ������� �ʾҽ��ϴ�.");
            return;
        }

        bgmSource.clip = bgm;
        bgmSource.Play();
    }

    /// <summary>
    /// ������� ����
    /// </summary>
    public void StopBGM()
    {
        bgmSource.Stop();
    }

    /// <summary>
    /// ��ư Ŭ�� ȿ����
    /// </summary>
    public void PlayButtonSound()
    {
        PlaySFX(BottonSFX);
    }

    /// <summary>
    /// ȿ���� ���
    /// </summary>
    public void PlaySFX(AudioClip clip)
    {
        if (clip == null)
        {
            Debug.LogWarning("AudioClip�� ������� �ʾҽ��ϴ�.");
            return;
        }

        sfxSource.PlayOneShot(clip);
    }
}