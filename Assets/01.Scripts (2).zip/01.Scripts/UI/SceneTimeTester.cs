using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class SceneTimeTester : MonoBehaviour
{
    [Header("UI �ؽ�Ʈ ���� (TextMeshPro)")]
    [SerializeField] private TextMeshProUGUI timeInfoText;

    private void Start()
    {
        string currentSceneName = SceneManager.GetActiveScene().name;

        if (SceneTimeManager.Instance != null)
        {
            float awaySeconds = SceneTimeManager.Instance.ConsumeElapsedSeconds(currentSceneName);

            if (timeInfoText != null)
            {
                if (awaySeconds > 0)
                {
                    timeInfoText.text = $"[{currentSceneName}]\n����� �ð�: {awaySeconds:F1}��";
                }
                else
                {
                    timeInfoText.text = $"[{currentSceneName}]\n��� ���� (0��)";
                }
            }

            Debug.Log($"[{currentSceneName}] ����! ������ ��� �ð�: {awaySeconds:F1}��");
        }
        else
        {
            if (timeInfoText != null)
            {
                timeInfoText.text = "SceneTimeManager�� �����ϴ�!";
            }
        }
    }
}
